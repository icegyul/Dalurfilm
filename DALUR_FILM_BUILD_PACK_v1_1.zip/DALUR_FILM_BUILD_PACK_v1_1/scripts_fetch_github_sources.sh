#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-third_party/source}"
mkdir -p "$ROOT"

fetch_repo() {
  local name="$1"
  local url="$2"
  local ref="$3"
  local dir="$ROOT/$name"

  if [ -d "$dir/.git" ]; then
    git -C "$dir" fetch --depth 1 origin "$ref" || true
  else
    git clone --filter=blob:none --no-checkout "$url" "$dir"
  fi

  git -C "$dir" fetch --depth 1 origin "$ref" || true
  git -C "$dir" checkout --detach "$ref"
}

fetch_repo "android-camera-samples"   "https://github.com/android/camera-samples.git"   "2f10e46fc7a09f7208f8d6de72482ecf3e5fb85a"

fetch_repo "android-gpuimage-plus"   "https://github.com/wysaid/android-gpuimage-plus.git"   "32bf703b9ffe49036853d027bc3350491985feae"

fetch_repo "google-timeline-visualizer"   "https://github.com/mahlernim/google-timeline-visualizer.git"   "785c814a03b32aaa8db965589e7d498d1ded5795"

fetch_repo "NextLevel"   "https://github.com/NextLevel/NextLevel.git"   "2fa42500caf7edd7136d23b64d9ecb5684d93d07"

fetch_repo "maplibre-native"   "https://github.com/maplibre/maplibre-native.git"   "9ee6f1c3b5b97fc2cba1c1042cadef87fa158476"

echo "DALUR film GitHub sources fetched and pinned."
