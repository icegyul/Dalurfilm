# DALUR film — GitHub Build Source Pack v1.0
Generated: 2026-09-13
Purpose: OpenCode + Muse Spark 1.3 one-shot implementation

## A. REQUIRED SOURCE / REFERENCE SET

### 1) Android official camera reference
Repository: https://github.com/android/camera-samples
Pinned ref: 2f10e46fc7a09f7208f8d6de72482ecf3e5fb85a

Use:
- CameraX/Camera2 camera scaffolding
- video capture
- HDR/10-bit capability detection
- manual ISO/shutter/focus samples
- RAW/DNG reference
- runtime unsupported-device handling

Relevant paths:
- samples/camerax-hdrvideo/
- samples/camera2-manualcontrols/
- samples/camera2-raw/
- samples/camerax-effects/
- samples/camerax-video/
Do not copy the catalog UI. Rebuild DALUR UI.

### 2) Android GPU filter/video engine
Repository: https://github.com/wysaid/android-gpuimage-plus
Pinned ref: 32bf703b9ffe49036853d027bc3350491985feae
License: MIT

Verified current README states:
- CameraX support via CameraXProvider
- real-time image/camera/video filtering
- CGEFrameRenderer
- CGEFrameRecorder
- custom shader filters
- rule-string based effects
- v3.2.0 dependency available

Preferred integration:
- Android dependency: org.wysaid:gpuimage-plus:3.2.0
- If 16 KB page compatibility is required, use the 3.2.0-16k variant
- Use GPUImage Plus for the GPU film/effect pipeline, not for device camera control.

### 3) Journey animation reference
Repository: https://github.com/mahlernim/google-timeline-visualizer
Pinned ref: 785c814a03b32aaa8db965589e7d498d1ded5795
License: MIT

Use as architecture/reference for:
- Timeline JSON parsing
- GeoPoint/path processing
- moving marker animation
- camera movement presets
- long-trip compression
- local MP4 rendering
- portrait/square/landscape export
- local-only processing

Do NOT copy:
- app branding
- UI
- product copy
- Google Timeline-specific product assumptions
- unrelated import/restore flows

DALUR implementation:
Capture GPS points directly at shutter/record events.
Build a DALUR Photo Journey model from local media metadata + GPS.
Render an original DALUR animation: path line → destination → photo reveal → hold → continue.

### 4) iOS camera foundation
Repository: https://github.com/NextLevel/NextLevel
Pinned ref: 2fa42500caf7edd7136d23b64d9ecb5684d93d07
License: MIT

Current README states:
- Swift 6
- iOS 16+
- AVFoundation-based camera system
- photo capture
- RAW/JPEG/video frame
- configurable video encoding/compression
- white balance/focus/exposure
- configurable frame rate
- HEVC photo option
- custom buffer processing

Use as a capture foundation/reference for iOS.
For final DALUR color pipeline, use Metal/Core Image/AVFoundation as appropriate.

### 5) Cross-platform native map rendering
Repository: https://github.com/maplibre/maplibre-native
Pinned ref: 9ee6f1c3b5b97fc2cba1c1042cadef87fa158476
License: BSD 2-Clause

Use for:
- Android map
- iOS map
- vector-tile map rendering
- local route overlays
- photo markers
- camera animation

Map style/tile provider MUST be configurable.
Do not hard-code an unlicensed third-party tile endpoint into production.
Required attribution must be shown according to the selected provider/style.

## B. REFERENCE-ONLY PROJECT

### PhotonCam
Repository: https://github.com/cinethe-zs/photoncam
Do NOT vendor code or assets by default.

Reason:
Its README documents third-party Hald CLUT film simulations under GPLv3 and trademarked film-stock names/assets. DALUR must use original DALUR LUTs/recipes and avoid inheriting incompatible GPL assets.

Use only as UX/feature research:
- film-stock selector
- film canister visual language
- shot counter
- grain/light-leak concepts
- 3D LUT workflow
- background processing
- rangefinder-inspired interaction

## C. SOURCE ACQUISITION POLICY

OpenCode MUST:
1. Clone or fetch the required repositories above into `third_party/source/` at the pinned ref when source inspection is necessary.
2. Prefer package/dependency integration for stable libraries.
3. Never silently copy GPL/AGPL/LGPL assets or code into DALUR.
4. Preserve required MIT/BSD notices in `THIRD_PARTY_NOTICES/`.
5. Record exact source commit in `THIRD_PARTY_LOCK.json`.
6. Re-run license scan before release packaging.

## D. THIRD PARTY LOCK FILE FORMAT

Example:
{
  "sources": [
    {
      "name": "android-camera-samples",
      "repo": "https://github.com/android/camera-samples",
      "ref": "2f10e46fc7a09f7208f8d6de72482ecf3e5fb85a",
      "usage": "reference"
    },
    {
      "name": "android-gpuimage-plus",
      "repo": "https://github.com/wysaid/android-gpuimage-plus",
      "ref": "32bf703b9ffe49036853d027bc3350491985feae",
      "license": "MIT",
      "usage": "android-runtime"
    },
    {
      "name": "google-timeline-visualizer",
      "repo": "https://github.com/mahlernim/google-timeline-visualizer",
      "ref": "785c814a03b32aaa8db965589e7d498d1ded5795",
      "license": "MIT",
      "usage": "journey-reference"
    },
    {
      "name": "NextLevel",
      "repo": "https://github.com/NextLevel/NextLevel",
      "ref": "2fa42500caf7edd7136d23b64d9ecb5684d93d07",
      "license": "MIT",
      "usage": "ios-camera-foundation"
    },
    {
      "name": "maplibre-native",
      "repo": "https://github.com/maplibre/maplibre-native",
      "ref": "9ee6f1c3b5b97fc2cba1c1042cadef87fa158476",
      "license": "BSD-2-Clause",
      "usage": "map-rendering"
    }
  ]
}

## E. IMPORTANT TECHNICAL RULE

OpenCode MUST NOT claim that GitHub source automatically provides real Log capture.

Android and iOS Log/flat capture are device/profile dependent.
The implementation must query actual camera capability/profile support at runtime.

If a device does not expose a true Log capture profile:
- do not fake a Log label,
- disable Log recording,
- explain the limitation,
- keep LUT monitoring and other supported features working.

HEVC/H.265 should be preferred when the hardware encoder supports it.
ProRes and 10-bit are conditional on the actual device capability.
