# DALUR film — ONE-SHOT MASTER DEVELOPMENT SPEC v1.1
Date: 2026-09-13
Development environment: OpenCode + Muse Spark 1.3
Execution model: autonomous implementation → test → fix → package → release-candidate audit

THIS FILE IS THE SINGLE SOURCE OF TRUTH.
OpenCode should read this file first and use it as the complete implementation contract.

======================================================================
PART A — MASTER PRODUCT SPEC
======================================================================

# DALUR film — MASTER DEVELOPMENT SPEC v1.0

**Project:** DALUR film  
**Primary objective:** Premium mobile camera app with film-recipe workflow, professional video mode, GPS photo map, and Journey video generation  
**Development agent:** OpenCode + Muse Spark 1.3  
**Execution style:** One-shot autonomous build → test → package → release-candidate audit  
**Initial target:** Android APK/AAB + iOS App Store-ready source/build when macOS/Xcode environment is available  
**Target paid price:** USD 7.99 (within the agreed USD 5–10 range)  
**Community:** NONE  
**Film marketplace:** POSTPONED until physical app verification is complete

---

## 0. NON-NEGOTIABLE EXECUTION RULE

This document is the single source of truth for the first DALUR film build.

OpenCode MUST:

1. Inspect the repository/workspace and local toolchain first.
2. Decide the implementation architecture autonomously.
3. Implement the full release-candidate feature set below without asking the user to make routine design or engineering choices.
4. Use best-effort fallbacks where a hardware feature is unavailable.
5. Never fake unsupported camera capabilities.
6. Build, test, lint, package, and produce a verification report before declaring completion.
7. Fix discovered build/test/runtime issues automatically and rerun verification.
8. Keep all secrets out of source control.
9. Keep marketplace, creator payouts, social/community, and promotional web production OUT of this first app build.
10. Do not stop at a prototype. The target is a production-grade release candidate.

Only stop and request user intervention when an external credential, signing certificate, Apple Developer account, Google Play account, physical camera hardware, or other genuinely unavailable external dependency makes a step impossible. In that case, complete every other possible step and produce the exact remaining action list.

---

# 1. PRODUCT DEFINITION

## 1.1 Product name

**DALUR film**

Brand treatment:
- Primary display name: `DALUR film`
- Keep lowercase `film` in product-facing UI unless platform conventions require otherwise.
- Do not use “DALUR FILM CAMERA” as the main product name.

## 1.2 Product statement

DALUR film is a premium camera app built around one idea:

> **Your camera. Your film. Your moments.**

The app combines:
- extremely simple everyday shooting,
- a true professional video camera mode,
- non-destructive film/LUT preview,
- user-created film recipes,
- GPS-based photo mapping,
- animated Journey videos.

It is NOT a social network.

## 1.3 Business model for v1

- Paid app.
- Target list price: **USD 7.99**.
- No subscription.
- No advertising.
- No mandatory account.
- No community feed.
- No comments.
- No likes.
- No follows.
- No creator profiles in v1.
- No marketplace transactions in v1.

### Later business model

After the real app build is installed and physically validated:
- Film Recipe Marketplace
- Users can buy and sell film recipes.
- Platform takes a marketplace commission.
- Exact commission percentage and IAP/payment architecture will be decided in the marketplace phase.
- The marketplace is NOT to be implemented as an active service in this first build.

---

# 2. PRODUCT PRINCIPLES

## 2.1 Easy first

A normal user should be able to open the app and take a beautiful photo/video without knowing anything about exposure, LUTs, codecs, Log, ISO, or color science.

## 2.2 Deep when needed

The PRO mode should become a serious camera interface for experienced users.

## 2.3 Non-destructive color workflow

Critical rule:

**The selected film/LUT must NOT be permanently baked into the professional Log recording.**

When supported by the hardware pipeline:

`Camera sensor → Log/flat capture → encoded original file`

while separately:

`Camera sensor → Log/flat capture → monitoring LUT → display`

Thus:
- Live preview can be LOG.
- Live preview can be LUT.
- Recorded professional master remains LOG/flat.
- Playback can show LOG or re-apply the capture LUT non-destructively.
- The selected LUT/film recipe is stored as metadata/sidecar information where possible.

## 2.4 Hardware honesty

Never label standard SDR/HDR capture as “Log” if the device does not expose a real Log/flat capture profile.

Implement capability detection per device.

When true Log is unavailable:
- hide or disable the Log selector,
- show the reason in the capability sheet,
- use the best supported high-quality profile,
- keep the rest of the app functional.

---

# 3. APP INFORMATION ARCHITECTURE

Primary navigation must stay simple.

## Bottom navigation

### CAMERA
Main camera.

### FILMS
Owned/local film recipes.

### MAP
Photos and videos on a GPS map.

### JOURNEYS
Automatically generated or manually assembled GPS/photo stories.

No social/community tab.

No marketplace tab in v1.

## Settings

Accessible from the top-right icon.

Contains:
- Camera defaults
- Display mode
- LUT preview preference
- Playback color mode
- Storage location
- External SSD status
- Location permission
- Photo library permission
- Microphone permission
- Export quality
- Haptics
- Accessibility
- About
- Licenses
- Privacy
- Terms
- Diagnostics / capability report

---

# 4. CAMERA — EASY MODE

The normal camera interface must be visually calm and understandable in under 5 seconds.

## 4.1 Main screen

Required controls:

- PHOTO / VIDEO toggle
- Lens selector: available device lenses only
- Film selector
- Large shutter button
- Front/back camera switch
- Flash / torch
- Gallery last-shot thumbnail
- PRO toggle
- Optional zoom control

Do NOT expose advanced numbers by default.

## 4.2 Film selection

Film strip should show real-time preview thumbnails.

User interaction:

1. Tap film.
2. Live camera updates.
3. Swipe horizontally to browse.
4. Tap selected film again to open film detail.

Film detail can show:
- name
- mood
- sample image
- intensity
- whether the film is local / installed / imported

## 4.3 Photo capture

The selected film should be applied to the preview and final PHOTO output according to the selected user-facing capture mode.

For standard photo mode:
- default behavior may create the intended finished look.
- retain original source where practical and where storage policy allows.
- preserve recipe metadata.

For PRO photo:
- support non-destructive workflow where supported.

## 4.4 Video capture

Standard mode should support:
- 1080p
- 4K where supported
- device-supported frame rates
- HEVC/H.265 where available
- H.264 fallback where required
- stereo/mic input where supported
- stabilization where supported

The app must show only valid device combinations.

Never present unsupported resolution/frame-rate/codec combinations as selectable.

---

# 5. CAMERA — PRO MODE

PRO mode is inspired by the information architecture of Blackmagic Camera, but must have its own DALUR visual identity.

## 5.1 PRO top HUD

Show compact, readable values such as:

- REC state
- resolution
- FPS
- codec
- color profile
- LUT preview state
- timecode / clip duration
- remaining storage
- external storage status
- audio level

## 5.2 Manual camera controls

When exposed by the platform/device:

- ISO
- shutter speed or shutter angle where possible
- exposure compensation
- white balance
- tint
- focus mode
- manual focus
- lens
- zoom
- stabilization
- ND/other hardware controls only if the device actually exposes them

## 5.3 Monitoring tools

Implement where platform/device supports them:

- histogram
- waveform or compact luminance scope if feasible
- zebra
- focus peaking
- focus assist
- false color
- framing guides
- center marker
- safe areas
- grid
- audio meters

Prioritize the tools that can be made reliable on real devices over decorative UI.

## 5.4 LOG / LUT monitoring modes

Two primary monitoring states:

### LOG VIEW
The preview displays the captured Log/flat image without the creative LUT.

### LUT VIEW
The preview displays the same Log/flat capture through the selected monitoring LUT.

Fast toggle between LOG and LUT must be available during shooting.

UI indicator must make the current state obvious.

Example:

`MONITOR: LUT`
`LUT: DALUR SUMMER 01`

## 5.5 Recording behavior

Professional recording rule:

**Recorded master = LOG/flat original.**

The monitoring LUT must not be baked into the professional master.

The selected LUT is retained as:
- recipe ID,
- recipe version,
- LUT hash/version,
- intensity,
- other color parameters,
- capture timestamp,
- camera profile,
- exposure settings,
- white balance settings,
- GPS if permitted.

Use embedded metadata where the file/container supports it; otherwise create a sidecar JSON.

## 5.6 Playback color modes

Professional clip playback must provide:

### LOG
View the recorded master as recorded.

### LUT
Re-apply the capture LUT/recipe for monitoring.

The LUT playback mode must not overwrite the master.

User should be able to switch between the two states without re-encoding the source clip.

---

# 6. CODECS

## 6.1 Default consumer video codec

Prefer:

**HEVC / H.265**

when supported and appropriate.

Fallback:

**H.264**

## 6.2 Professional formats

Support as permitted by the actual platform/hardware:

- HEVC 10-bit
- ProRes family on supported iOS hardware
- Log/flat professional capture profile on supported hardware

Do not promise ProRes/Log on devices that cannot actually supply it.

## 6.3 Capability matrix

At runtime, build a device capability report containing:

- camera lenses
- maximum resolution
- supported FPS
- HEVC support
- 10-bit support
- HDR support
- Log support
- ProRes support
- USB external storage support
- hardware stabilization support
- autofocus/manual-focus capabilities

The UI must be driven by this matrix.

---

# 7. USB-C EXTERNAL RECORDING — REQUIRED

This is a first-class PRO feature.

## 7.1 External SSD recording

Where platform and device support direct external storage:

`Camera → DALUR processing → encoder → external USB-C SSD`

Provide:
- detect external storage
- show mounted volume name
- free space
- record destination selector
- start/stop recording
- safe close/finalize
- recovery behavior after unexpected disconnect
- file browser for recorded DALUR clips

## 7.2 File integrity

Before exposing a clip to the gallery as finished:
- finalize container
- flush buffers
- verify file exists
- verify non-zero duration
- verify readable metadata
- optionally perform a lightweight checksum/integrity test

If the external SSD disconnects during recording:
- stop safely where possible
- preserve already written data
- show a clear error state
- never silently lose the clip

## 7.3 USB-C external recorder / monitor

Treat this as a separate capability from direct SSD recording.

Do not claim generic support across all phones.

Implement only where OS/hardware APIs actually expose it.

If not available on a device, hide the control or mark it unsupported.

---

# 8. FILM ENGINE

The film engine is one of the core product assets.

## 8.1 Film recipe model

Use a versioned JSON schema.

Minimum structure:

```json
{
  "id": "dalur_summer_01",
  "version": 1,
  "name": "Summer 01",
  "author": "DALUR",
  "type": "film",
  "lut": {
    "format": "cube",
    "size": 33,
    "source": "bundled://luts/summer_01.cube",
    "hash": "..."
  },
  "intensity": 0.85,
  "tone": {
    "exposure": 0.0,
    "contrast": 0.0,
    "highlights": 0.0,
    "shadows": 0.0,
    "fade": 0.0
  },
  "color": {
    "temperature": 0.0,
    "tint": 0.0,
    "saturation": 0.0
  },
  "effects": {
    "grain": 0.15,
    "halation": 0.08,
    "bloom": 0.06,
    "vignette": 0.04,
    "chromaticAberration": 0.02
  }
}
```

The exact schema may be expanded as implementation progresses, but it MUST remain backward compatible through `version`.

## 8.2 LUT support

Support standard 3D Cube LUTs:
- 17-point
- 33-point
- additional sizes only if implementation is stable

Implement:
- validation
- color-space labeling
- import
- preview
- intensity control
- recipe metadata

Never treat an arbitrary LUT as automatically color-correct. The UI should distinguish:
- creative LUT
- technical transform
- unknown LUT

## 8.3 Built-in films

Ship a small high-quality starter set.

Suggested initial set:

- DALUR Memory
- DALUR Summer
- DALUR Rain
- DALUR Sunset
- DALUR Night
- DALUR Soft
- DALUR Mono
- DALUR Cinema

These are DALUR originals for the app and should not imitate copyrighted brand presets by name.

Do NOT copy Kodak/Fujifilm/Polaroid branded recipes or proprietary assets.

## 8.4 Photo and video consistency

A film recipe must have a consistent visual identity across:
- live photo preview
- photo output
- video monitoring preview
- video playback LUT view

Where a given effect cannot be implemented in a color-managed video pipeline, use a documented approximation instead of silently changing the recipe.

---

# 9. FILM CREATOR — LOCAL ONLY IN V1

The marketplace is deferred, but the creation engine should be built now.

## 9.1 Easy Creator

Simple controls:

- Mood
- Warm / Cool
- Bright / Dark
- Soft / Contrast
- Grain
- Glow
- Fade
- Color strength

## 9.2 PRO Creator

Advanced controls:

- Exposure
- Contrast
- Highlights
- Shadows
- Blacks
- Whites
- Tone curve RGB
- Individual RGB curves
- HSL
- Color grading
- Temperature
- Tint
- Saturation
- Grain amount
- Grain size
- Halation
- Bloom
- Vignette
- Chromatic aberration
- LUT import
- LUT strength
- Preview split view
- Before/after hold gesture

## 9.3 Save

`SAVE FILM`

Save locally with:
- unique ID
- version
- author = local user
- creation timestamp
- source LUT hash if applicable

The local recipe must be exportable to a portable recipe package for future marketplace integration.

Do NOT implement selling/buying yet.

---

# 10. GPS PHOTO MAP

This is a core DALUR differentiator.

## 10.1 Capture metadata

When the user grants location permission and location is available, attach:
- latitude
- longitude
- altitude where available
- timestamp
- heading where available
- accuracy

Location capture must be opt-in and transparent.

## 10.2 MAP screen

Display the user's photos/videos on a map.

At minimum:
- map
- route/path when multiple chronological points exist
- photo markers
- selected photo preview
- date/time
- location name if available
- film name

## 10.3 Timeline route animation

Inspired by the interaction model of Google Timeline-style visualization, but implement an original DALUR design.

Sequence:

1. Map opens.
2. Path draws progressively.
3. Camera/map view moves along the path.
4. When reaching a capture point, the related photo appears with a soft “snap” animation.
5. Hold on the photo.
6. Continue along the path.
7. Finish by showing the whole route and final photo.

Do not copy another product's visual assets or source code blindly.

---

# 11. JOURNEY VIDEO ENGINE

This feature turns a set of GPS-tagged captures into a finished short video.

## 11.1 Input

- selected journey/date range
- ordered GPS points
- photos/videos
- film metadata
- optional title

## 11.2 Templates

Initial templates:

### MEMORY
Slow, emotional, film-like.

### CINEMA
Clean, cinematic, controlled movement.

### POSTCARD
Photo-card style.

### TRAVEL
Faster movement, energetic route reveal.

## 11.3 Export ratios

- 9:16
- 1:1
- 16:9

## 11.4 Duration presets

- 15 sec
- 30 sec
- 60 sec

## 11.5 Motion

At minimum:
- path draw
- map camera move
- photo pop-in
- photo hold
- transition to next point
- final route overview

## 11.6 Export

Where supported, export:
- HEVC/H.265
- H.264 fallback
- high-quality local file
- save to photo library
- share sheet

The Journey renderer must work entirely locally where feasible.

---

# 12. DATA STORAGE

## Local-first

V1 must work without an account.

Persist locally:
- films
- film recipes
- photo metadata index
- journey data
- preferences
- capability cache

Recommended architecture:
- SQLite/Core Data/Room depending on platform
- shared logical schema
- file system for media
- JSON sidecars where metadata cannot be embedded

Do not add a backend solely for v1.

---

# 13. MAP TECHNOLOGY

Choose a legally redistributable, production-suitable map stack.

Preferred direction:
- MapLibre-compatible architecture OR native Apple MapKit + native Android map implementation if this gives substantially better stability.

Requirements:
- no mandatory API key for basic local map development if possible
- production attribution handled correctly
- route polyline rendering
- photo markers
- camera animation
- stable offline/local metadata behavior

Map tile licensing/attribution MUST be documented before release.

---

# 14. PLATFORM ARCHITECTURE

## Recommendation

Use a cross-platform UI layer only where it does not compromise camera/media functionality.

Recommended split:

### Shared
- design system
- navigation structure
- film recipe schema
- metadata schema
- journey model
- business rules

### Android native
- Camera2 / CameraX where appropriate
- MediaCodec / MediaMuxer
- OpenGL ES / Vulkan-based GPU pipeline as needed
- USB host / Storage Access Framework
- Android GPS/location
- MediaStore

### iOS native
- AVFoundation
- VideoToolbox
- Core Image / Metal
- FileProvider / Files integration
- external storage APIs
- Core Location
- Photos framework

Do not force a generic camera plugin to handle professional Log/codec/USB features if platform-native implementation is materially more reliable.

---

# 15. OPEN-SOURCE REFERENCE PROJECTS

Use these as research/reference components, not as permission to copy code without license review.

### Android
- `wysaid/android-gpuimage-plus`
  - OpenGL image/camera/video filter library
  - MIT license
  - Useful for filter pipeline concepts and CameraX integration.
- `android/camera-samples`
  - official Android camera examples
  - useful for modern CameraX/Camera2 patterns, HDR and video capture.
- `nekocode/CameraFilter`
  - realtime camera filters using OpenGL shaders
  - Apache-2.0
- `aserbao/AndroidCamera`
  - useful product/reference study for camera, video, filters, stickers and editing
  - LICENSE status must be reviewed before any code reuse.

### iOS
- `BradLarson/GPUImage3`
  - Swift + Metal GPU image/video processing
  - BSD-3-Clause
- `yangKJ/Harbeth`
  - Metal/CoreImage/MPS filtering and LUT support
  - verify current license before shipping any copied code.
- `jsharp83/metalcamera`
  - Metal + AVFoundation camera/video pipeline reference.

### Timeline/reference
- Google Timeline Visualizer project supplied by the user
  - Study the interaction and route animation concept.
  - Do NOT copy branding/UI assets blindly.

Before using any third-party code:
1. record repository, version/commit, license;
2. copy license text when required;
3. add third-party notices;
4. prefer clean-room reimplementation when licensing is unclear.

---

# 16. DESIGN SYSTEM

Visual identity:
- premium
- cinematic
- quiet
- modern
- tactile
- not cyberpunk
- not overloaded
- no social-media-style clutter

Primary camera screen should feel like a real camera, not a dashboard.

Easy mode:
- large controls
- minimal labels
- film thumbnails
- strong live preview

PRO mode:
- dense but organized
- monospaced/technical numerals only where useful
- hierarchy inspired by dedicated cinema cameras
- dark UI
- no gratuitous decoration

Accessibility:
- minimum touch target suitable for mobile
- sufficient contrast
- VoiceOver/TalkBack labels
- dynamic type where compatible
- reduced motion option

---

# 17. ERROR HANDLING

Every major hardware/media operation must have explicit states:

- permission denied
- camera unavailable
- microphone unavailable
- unsupported codec
- unsupported Log
- LUT invalid
- LUT color-space mismatch
- external SSD unavailable
- external SSD disconnected
- storage full
- export failed
- GPS unavailable
- location permission denied
- media library denied
- unsupported frame rate
- thermal throttling risk
- low battery warning where practical

Errors must explain what the user can do next.

---

# 18. PERFORMANCE TARGETS

## Camera preview

Target:
- stable 30 FPS minimum
- 60 FPS target where hardware allows

## Startup

- cold launch should feel immediate
- delay heavyweight libraries until needed

## GPU

- avoid full-resolution CPU color transforms per frame
- use GPU textures/shaders
- reuse buffers
- avoid unnecessary copies

## Recording

- separate preview rendering from encoder lifecycle
- drop frames gracefully rather than crashing
- preserve audio/video sync

## Journey rendering

- background task
- progress indicator
- cancellation support
- memory-safe processing

---

# 19. SECURITY / PRIVACY

Default principles:
- camera data stays local in v1 unless the user explicitly shares/export content.
- no account required.
- no analytics dependency required for core camera operation.
- no silent background location collection.
- location permission used only for requested mapping features.
- microphone requested only for video/audio capture.
- photo library access minimized to required functionality.

Generate privacy documentation templates during the build, but do not invent a fake public URL.

---

# 20. TESTING REQUIREMENTS

## Unit tests

Cover:
- recipe parsing
- recipe version migration
- LUT validation
- metadata serialization
- GPS ordering
- Journey timeline ordering
- capability matrix
- filename generation

## Integration tests

Cover:
- photo capture
- video recording
- filter preview
- LUT toggle
- playback LOG/LUT toggle
- gallery save
- GPS metadata
- map markers
- route animation
- Journey export
- external storage selection

## Device tests

At minimum, if hardware is available:
- one modern Android device
- one Android device with USB-C OTG/SSD
- one modern iPhone if iOS build is available

## Regression tests

Run after every major camera/media pipeline change.

---

# 21. BUILD REQUIREMENTS

## Android

Current Google Play requirement as of August 31, 2026:
- target Android 16 / API level 36 or higher for new apps and updates.

Therefore:
- `compileSdk >= 36`
- `targetSdk >= 36`
- current stable Android Gradle Plugin compatible with the installed JDK
- signed release build configuration

Produce:
- debug APK
- release APK (signed if keystore exists; otherwise unsigned release artifact + signing instructions)
- release AAB

## iOS

As of April 28, 2026, App Store Connect uploads require Xcode 26 or later with the iOS 26 SDK or later.

Therefore:
- project must support current Xcode 26+
- deployment target should be selected based on actual device feature needs
- do not choose a deployment target that prevents required AVFoundation/Metal capabilities without a reason

Produce when a Mac/Xcode environment is available:
- simulator build
- physical-device build
- Release archive (`.xcarchive`)
- exportable `.ipa` when signing credentials are available

If building on Windows/Linux:
- finish all shared/iOS source work
- validate project structure
- run static checks
- document the exact Mac-only commands required for archive/sign/upload.

---

# 22. RELEASE-CANDIDATE CHECKLIST

The build is NOT DONE until all applicable items are checked.

### Core camera
- [ ] Photo capture works
- [ ] Video capture works
- [ ] Front/back switching works
- [ ] Lens switching works
- [ ] Film preview works
- [ ] Film intensity works
- [ ] Gallery save works

### PRO
- [ ] PRO toggle works
- [ ] ISO
- [ ] shutter
- [ ] WB
- [ ] focus
- [ ] histogram
- [ ] zebra
- [ ] focus assist/peaking where supported
- [ ] false color where supported
- [ ] LOG preview where supported
- [ ] LUT preview
- [ ] LOG/LUT monitoring toggle
- [ ] professional recording master remains Log/flat
- [ ] playback LOG/LUT toggle
- [ ] HEVC/H.265
- [ ] ProRes where supported

### USB-C
- [ ] detect external SSD
- [ ] select external SSD
- [ ] record to SSD
- [ ] finalize safely
- [ ] handle disconnect
- [ ] verify output file

### GPS / Journey
- [ ] capture GPS metadata
- [ ] map markers
- [ ] chronological route
- [ ] animated path
- [ ] photo pop-in
- [ ] Journey export 9:16
- [ ] Journey export 1:1
- [ ] Journey export 16:9
- [ ] Journey export HEVC/H.264

### Quality
- [ ] no crash on permission denial
- [ ] no crash on unsupported codec
- [ ] no crash on full storage
- [ ] no crash on camera switch while recording
- [ ] no crash on external storage removal
- [ ] no memory leak observed in long preview/record test
- [ ] orientation tested
- [ ] dark/light system settings tested where supported
- [ ] accessibility labels checked

---

# 23. APP STORE / PLAY STORE READINESS

Prepare the repository for submission, but do not falsely claim the app is submitted.

Create `/store/` with:

- `app-name.md`
- `description-ko.md`
- `description-en.md`
- `subtitle-options.md`
- `keywords-ko.md`
- `keywords-en.md`
- `release-notes-v1.0.md`
- `privacy-policy-draft.md`
- `terms-draft.md`
- `support-page-draft.md`
- `review-notes.md`
- `store-assets-checklist.md`
- `age-rating-notes.md`
- `permissions-explanation.md`
- `third-party-licenses.md`

### App store positioning

Name:
`DALUR film`

Core message:
`A premium film camera for photos, Log video, and your memories on the map.`

Do not market v1 as a social network.

Do not mention features that are not actually enabled in the submitted build.

Important current platform requirements:
- Apple: iOS/iPadOS apps uploaded to App Store Connect must be built with Xcode 26+ using iOS/iPadOS 26+ SDK as of April 28, 2026.
- Google Play: new apps/updates must target Android 16 / API 36+ as of August 31, 2026.

---

# 24. MARKETPLACE GATE — DO NOT BUILD YET

Create architecture notes only.

The actual Film Recipe Marketplace MUST remain disabled and unimplemented as a live network product until the user has physically tested the app and approved the camera experience.

Do NOT implement in v1:
- user accounts for marketplace
- creator payout accounts
- Stripe/PayPal marketplace settlement
- Apple IAP for user-generated recipes
- Google Play Billing marketplace products
- creator profiles
- comments
- likes
- follows
- social feed
- public uploads
- ratings/reviews

Prepare only:
- portable recipe package format
- stable recipe IDs
- recipe versioning
- future marketplace API interface
- future purchase entitlement abstraction

The marketplace phase begins only after the physical app build is validated.

---

# 25. PROMOTIONAL WEBSITE GATE — DO NOT BUILD YET

Do not build the final marketing/landing page in this phase.

After the physical app is real and verified:
1. Create Film Recipe Marketplace.
2. Create DALUR film official promotional website.
3. Create launch visual assets.
4. Create App Store / Google Play campaign assets.

For now, only create a `/docs/marketing/` placeholder with the product positioning and future page outline.

---

# 26. RECOMMENDED REPOSITORY STRUCTURE

Adapt to the actual chosen framework, but keep equivalent separation:

```text
DALUR-film/
├─ app/
├─ android/
├─ ios/
├─ shared/
│  ├─ film-schema/
│  ├─ metadata/
│  └─ journey/
├─ camera-engine/
│  ├─ capture/
│  ├─ color/
│  ├─ lut/
│  ├─ recording/
│  └─ capabilities/
├─ map-engine/
├─ journey-engine/
├─ films/
│  ├─ bundled/
│  ├─ local/
│  └─ schemas/
├─ tests/
├─ docs/
│  ├─ architecture/
│  ├─ qa/
│  └─ marketing/
├─ store/
├─ scripts/
├─ builds/
└─ README.md
```

Use the framework's natural structure if a different organization is technically superior.

---

# 27. REQUIRED AUTOMATION SCRIPTS

Create scripts/commands for:

- clean
- lint
- unit test
- integration test
- Android debug build
- Android release build
- Android APK export
- Android AAB export
- iOS build where macOS exists
- iOS archive where macOS exists
- third-party license report
- capability report
- store-preflight

Example final outputs:

```text
builds/android/DALUR-film-debug.apk
builds/android/DALUR-film-release.apk
builds/android/DALUR-film-release.aab
builds/ios/DALUR-film.xcarchive
builds/ios/DALUR-film.ipa
```

Only generate paths that actually exist.

---

# 28. FINAL SELF-AUDIT REPORT

At the end of the run, generate:

`docs/qa/FINAL_RELEASE_CANDIDATE_AUDIT.md`

It must contain:

1. Build status
2. Test status
3. Device test status
4. Android APK path
5. Android AAB path
6. iOS archive/IPA path if produced
7. Camera capability matrix
8. Known limitations
9. Open-source license report
10. Store-readiness status
11. External credentials still required
12. Items intentionally deferred to Marketplace Phase
13. Items intentionally deferred to Promotional Website Phase
14. Exact commands used
15. Exact final git commit SHA

Use explicit states:

`PASS`
`PASS_WITH_LIMITATIONS`
`BLOCKED_EXTERNAL_DEPENDENCY`
`NOT_RUN`

Never write “complete” where a required capability was not actually tested.

---

# 29. GIT RULES

Before implementation:
- inspect current branch
- inspect git status
- do not overwrite unrelated user work

During work:
- commit logical milestones
- use meaningful commit messages

Suggested milestones:

1. `feat: initialize DALUR film camera architecture`
2. `feat: add easy camera and film engine`
3. `feat: add pro camera controls and monitoring`
4. `feat: add log lut workflow`
5. `feat: add hevc and external storage recording`
6. `feat: add gps photo map`
7. `feat: add journey renderer`
8. `test: add release candidate verification`
9. `chore: prepare store metadata and licenses`

Final commit:

`release: DALUR film v1.0.0 release candidate`

Record the final SHA in the audit report.

---

# 30. WHAT SUCCESS LOOKS LIKE

A person installs DALUR film and immediately understands:

**CAMERA → choose a film → shoot.**

A serious video user switches to PRO and sees:

**manual camera + LOG + LUT monitoring + HEVC/H.265 + supported professional codecs + USB-C SSD recording.**

After shooting, the person can open:

**MAP → see exactly where photos were taken.**

Then:

**JOURNEY → watch the route draw itself while photos appear at the exact places where they were captured.**

The user can create and save their own film recipes locally.

There is NO community clutter.

There is NO forced subscription.

The marketplace exists as a future expansion, not as a dependency for the camera experience.

---

# 31. FINAL INSTRUCTION TO OPENCODE + MUSE SPARK 1.3

Build DALUR film as a production-quality release candidate from this specification.

Do not merely create screens.

Implement real camera capture, real media pipelines, real LUT processing, real GPS metadata, real map rendering, real Journey rendering, and real package builds.

Use native platform camera/media APIs for capabilities that generic cross-platform abstractions cannot reliably provide.

Use open-source libraries only after license verification.

Do not fabricate Log capture or professional codecs on unsupported hardware.

Do not activate marketplace/community/backend features that are explicitly deferred.

Do not stop after the first successful compile. Continue through tests, packaging, and the final audit.

If a real-device-only feature cannot be verified in the current environment, mark it `BLOCKED_EXTERNAL_DEPENDENCY` or `NOT_RUN` and still complete all other work.

The final deliverable is not a design mockup. It is a buildable DALUR film v1.0.0 release candidate with Android APK/AAB artifacts and the strongest possible iOS App Store-ready project/archive supported by the environment.



======================================================================
PART B — GITHUB SOURCE / IMPLEMENTATION PATCH
======================================================================


# DALUR film — MASTER SPEC PATCH v1.1
Date: 2026-09-13

## PATCH 1 — GitHub source integration is now mandatory

OpenCode MUST read:
- DALUR_FILM_MASTER_DEVELOPMENT_SPEC_v1.0.md
- DALUR_FILM_GITHUB_SOURCE_PACK_v1.0.md

before implementing.

The GitHub source pack is part of the technical specification.

## PATCH 2 — Build architecture

Use a native-first architecture.

Android:
- Kotlin
- Jetpack Compose
- CameraX where sufficient
- Camera2 for low-level PRO controls
- GPUImage Plus for GPU filter/effect pipeline
- MediaCodec/MediaMuxer or the validated recorder pipeline for encoding
- WorkManager/foreground service for long renders where appropriate
- MapLibre Native for the map

iOS:
- Swift / SwiftUI
- AVFoundation
- NextLevel as a camera foundation where it reduces risk
- Metal/Core Image for the DALUR film pipeline
- AVAssetWriter / supported system encoders
- MapLibre Native or an equivalent native map layer

Shared:
- versioned Film Recipe JSON
- media metadata model
- GPS point model
- Journey model
- capability model
- deterministic export presets

## PATCH 3 — Priority order

P0:
1. Camera preview
2. Photo capture
3. Video capture
4. Film preview
5. Film save/load
6. GPS capture
7. Gallery/map
8. Journey animation preview
9. APK/AAB

P1:
10. PRO HUD
11. manual controls
12. histogram/zebra/focus tools
13. HEVC
14. real Log capability detection
15. LUT monitor toggle
16. playback LOG/LUT
17. external USB-C SSD recording
18. Journey MP4 export

P2:
19. iOS release candidate
20. accessibility and localization polish
21. store compliance package

No marketplace, no community, no promotional website.

## PATCH 4 — Journey implementation

Do not import Google Timeline.
Do not require Google account access.

DALUR creates its own photo journey from media captured by DALUR.

At capture:
- photo/video URI
- timestamp
- GPS
- altitude if available
- heading if available
- film recipe ID/version
- lens
- exposure
- video codec/profile

Journey renderer:
A. establish map
B. draw route
C. animate route line
D. move camera along route
E. pause at media point
F. animate photo reveal from that point
G. hold 0.8–2.5 seconds depending on photo count
H. continue
I. final route overview
J. export

Photo reveal should be a DALUR signature animation:
- pin pulse
- route dot grows
- photo card rises/fades/scales into place
- subtle film grain overlay
- optional film frame
- no excessive UI chrome

Presets:
- MEMORY
- CINEMA
- POSTCARD
- JOURNAL

Export:
- 9:16
- 1:1
- 16:9
- 1080p preferred
- HEVC if device/export pipeline supports it
- H.264 fallback

## PATCH 5 — PRO color architecture

Two monitoring states:
LOG VIEW
LUT VIEW

Recording master:
LOG/flat when actual device profile supports it.

Never bake the creative monitoring LUT into the PRO master.

Metadata:
- capture profile
- LUT recipe ID
- recipe version
- LUT hash
- intensity
- camera settings
- timestamp
- GPS

Playback:
- LOG
- LUT
- same master file

## PATCH 6 — USB-C

Implement direct external SSD recording where the OS/device allows it.

The capability layer must distinguish:
- internal storage
- removable storage
- external USB mass storage
- external monitor/recorder output

Do not conflate external SSD recording with HDMI/USB video output.

## PATCH 7 — Legal/licensing gate

Before release:
- generate THIRD_PARTY_NOTICES/
- include exact commit refs
- include license texts where required
- scan bundled assets
- scan dependencies
- fail release if GPL/AGPL content has been accidentally included

DALUR-original LUTs only.
No trademarked film stock names in bundled DALUR presets.

## PATCH 8 — release evidence

Before completion, generate:
release/
  DALUR-film-android-debug.apk
  DALUR-film-android-release.aab
  CHECKSUMS.txt
  DEVICE_CAPABILITY_REPORT.json
  TEST_REPORT.md
  THIRD_PARTY_NOTICES/
  STORE_READINESS.md

If signing credentials are unavailable, create unsigned or locally signed artifacts where technically possible and clearly mark store-signing as pending. Never claim a store upload occurred unless it actually did.


======================================================================
PART C — VERIFIED GITHUB SOURCE PACK
======================================================================

# DALUR film — GitHub Build Source Pack v1.0
Generated: 2026-09-13
Purpose: OpenCode + Muse Spark 1.3 one-shot implementation

## A. REQUIRED SOURCE / REFERENCE SET

### 1) Android official camera reference
Repository: https://github.com/android/camera-samples
Pinned ref: 2f10e46fc7a09f7208f8d6de72482ecf3e5fb85a

Use:
- CameraX/Camera2 camera scaffolding
- video capture
- HDR/10-bit capability detection
- manual ISO/shutter/focus samples
- RAW/DNG reference
- runtime unsupported-device handling

Relevant paths:
- samples/camerax-hdrvideo/
- samples/camera2-manualcontrols/
- samples/camera2-raw/
- samples/camerax-effects/
- samples/camerax-video/
Do not copy the catalog UI. Rebuild DALUR UI.

### 2) Android GPU filter/video engine
Repository: https://github.com/wysaid/android-gpuimage-plus
Pinned ref: 32bf703b9ffe49036853d027bc3350491985feae
License: MIT

Verified current README states:
- CameraX support via CameraXProvider
- real-time image/camera/video filtering
- CGEFrameRenderer
- CGEFrameRecorder
- custom shader filters
- rule-string based effects
- v3.2.0 dependency available

Preferred integration:
- Android dependency: org.wysaid:gpuimage-plus:3.2.0
- If 16 KB page compatibility is required, use the 3.2.0-16k variant
- Use GPUImage Plus for the GPU film/effect pipeline, not for device camera control.

### 3) Journey animation reference
Repository: https://github.com/mahlernim/google-timeline-visualizer
Pinned ref: 785c814a03b32aaa8db965589e7d498d1ded5795
License: MIT

Use as architecture/reference for:
- Timeline JSON parsing
- GeoPoint/path processing
- moving marker animation
- camera movement presets
- long-trip compression
- local MP4 rendering
- portrait/square/landscape export
- local-only processing

Do NOT copy:
- app branding
- UI
- product copy
- Google Timeline-specific product assumptions
- unrelated import/restore flows

DALUR implementation:
Capture GPS points directly at shutter/record events.
Build a DALUR Photo Journey model from local media metadata + GPS.
Render an original DALUR animation: path line → destination → photo reveal → hold → continue.

### 4) iOS camera foundation
Repository: https://github.com/NextLevel/NextLevel
Pinned ref: 2fa42500caf7edd7136d23b64d9ecb5684d93d07
License: MIT

Current README states:
- Swift 6
- iOS 16+
- AVFoundation-based camera system
- photo capture
- RAW/JPEG/video frame
- configurable video encoding/compression
- white balance/focus/exposure
- configurable frame rate
- HEVC photo option
- custom buffer processing

Use as a capture foundation/reference for iOS.
For final DALUR color pipeline, use Metal/Core Image/AVFoundation as appropriate.

### 5) Cross-platform native map rendering
Repository: https://github.com/maplibre/maplibre-native
Pinned ref: 9ee6f1c3b5b97fc2cba1c1042cadef87fa158476
License: BSD 2-Clause

Use for:
- Android map
- iOS map
- vector-tile map rendering
- local route overlays
- photo markers
- camera animation

Map style/tile provider MUST be configurable.
Do not hard-code an unlicensed third-party tile endpoint into production.
Required attribution must be shown according to the selected provider/style.

## B. REFERENCE-ONLY PROJECT

### PhotonCam
Repository: https://github.com/cinethe-zs/photoncam
Do NOT vendor code or assets by default.

Reason:
Its README documents third-party Hald CLUT film simulations under GPLv3 and trademarked film-stock names/assets. DALUR must use original DALUR LUTs/recipes and avoid inheriting incompatible GPL assets.

Use only as UX/feature research:
- film-stock selector
- film canister visual language
- shot counter
- grain/light-leak concepts
- 3D LUT workflow
- background processing
- rangefinder-inspired interaction

## C. SOURCE ACQUISITION POLICY

OpenCode MUST:
1. Clone or fetch the required repositories above into `third_party/source/` at the pinned ref when source inspection is necessary.
2. Prefer package/dependency integration for stable libraries.
3. Never silently copy GPL/AGPL/LGPL assets or code into DALUR.
4. Preserve required MIT/BSD notices in `THIRD_PARTY_NOTICES/`.
5. Record exact source commit in `THIRD_PARTY_LOCK.json`.
6. Re-run license scan before release packaging.

## D. THIRD PARTY LOCK FILE FORMAT

Example:
{
  "sources": [
    {
      "name": "android-camera-samples",
      "repo": "https://github.com/android/camera-samples",
      "ref": "2f10e46fc7a09f7208f8d6de72482ecf3e5fb85a",
      "usage": "reference"
    },
    {
      "name": "android-gpuimage-plus",
      "repo": "https://github.com/wysaid/android-gpuimage-plus",
      "ref": "32bf703b9ffe49036853d027bc3350491985feae",
      "license": "MIT",
      "usage": "android-runtime"
    },
    {
      "name": "google-timeline-visualizer",
      "repo": "https://github.com/mahlernim/google-timeline-visualizer",
      "ref": "785c814a03b32aaa8db965589e7d498d1ded5795",
      "license": "MIT",
      "usage": "journey-reference"
    },
    {
      "name": "NextLevel",
      "repo": "https://github.com/NextLevel/NextLevel",
      "ref": "2fa42500caf7edd7136d23b64d9ecb5684d93d07",
      "license": "MIT",
      "usage": "ios-camera-foundation"
    },
    {
      "name": "maplibre-native",
      "repo": "https://github.com/maplibre/maplibre-native",
      "ref": "9ee6f1c3b5b97fc2cba1c1042cadef87fa158476",
      "license": "BSD-2-Clause",
      "usage": "map-rendering"
    }
  ]
}

## E. IMPORTANT TECHNICAL RULE

OpenCode MUST NOT claim that GitHub source automatically provides real Log capture.

Android and iOS Log/flat capture are device/profile dependent.
The implementation must query actual camera capability/profile support at runtime.

If a device does not expose a true Log capture profile:
- do not fake a Log label,
- disable Log recording,
- explain the limitation,
- keep LUT monitoring and other supported features working.

HEVC/H.265 should be preferred when the hardware encoder supports it.
ProRes and 10-bit are conditional on the actual device capability.


======================================================================
PART D — ONE-SHOT DELIVERY CONTRACT
======================================================================

OpenCode MUST complete the project without routine clarification questions.

1. Inspect current workspace and installed toolchains.
2. Acquire the pinned GitHub sources with the supplied fetch script.
3. Design the repository so source separation is obvious:
   - app/
   - shared/
   - android/
   - ios/
   - film-engine/
   - journey-engine/
   - map/
   - third_party/source/
   - THIRD_PARTY_NOTICES/
   - release/
4. Implement production code, not a clickable mockup.
5. Prefer stable package integration for libraries and vendored source only where adaptation is required.
6. Maintain a `THIRD_PARTY_LOCK.json` containing exact commit refs.
7. Generate original DALUR film LUT assets and recipes. Do not ship third-party branded film stock LUTs.
8. Run automated tests, lint, static analysis, dependency/license scan and build verification.
9. When a physical device is connected, execute the hardware capability test suite.
10. When hardware is not connected, generate a clear `DEVICE_VALIDATION_PENDING` report instead of pretending it passed.
11. Build:
   - Android debug APK
   - Android release APK
   - Android release AAB
   - iOS build/archive when a macOS/Xcode signing-capable environment exists
12. Produce final release evidence:
   release/DALUR-film-android-release.apk
   release/DALUR-film-android-release.aab
   release/CHECKSUMS.txt
   release/DEVICE_CAPABILITY_REPORT.json
   release/TEST_REPORT.md
   release/STORE_READINESS.md
   release/THIRD_PARTY_LOCK.json
   release/THIRD_PARTY_NOTICES/
13. Fix build/test failures automatically and repeat until clean or until an external dependency genuinely blocks progress.
14. Never hide or fake an unsupported capability.
15. Marketplace, social/community, creator payouts and promotional website are OUT OF SCOPE for this build.
16. Do not create Apple/Google store submissions automatically unless valid developer accounts, signing identities, provisioning, certificates and store access are actually available.
17. Finish by printing:
   - implementation summary
   - exact build artifact paths
   - test totals
   - device capability result
   - license result
   - store-readiness result
   - known limitations
   - exact remaining external actions
   - final Git SHA

======================================================================
PART E — NON-NEGOTIABLE COLOR / RECORDING RULE
======================================================================

PRO monitoring:
LOG VIEW ↔ LUT VIEW

Professional source recording:
REAL LOG/FLAT master only on hardware that exposes a genuine supported profile.

The creative LUT is a monitoring layer and must not be baked into the PRO master.

Playback:
LOG = original master view
LUT = non-destructive monitoring transform using the capture recipe

Persist recipe ID/version/hash and camera metadata.

======================================================================
PART F — NON-NEGOTIABLE USB-C RULE
======================================================================

USB-C external SSD recording is a first-class feature where the OS/device allows it.

The implementation must:
- detect external media
- display free space
- select storage target
- write safely
- finalize files
- recover from disconnect where possible
- verify the resulting media file

External SSD recording and external monitor/recorder output are separate capabilities.

======================================================================
PART G — NON-NEGOTIABLE JOURNEY RULE
======================================================================

Journey is built from DALUR-captured media metadata and GPS points.

No Google sign-in is required.

Route animation:
route line → moving camera → capture point → photo reveal → hold → next point → final route overview.

Export:
9:16 / 1:1 / 16:9.

The exported Journey video is an original DALUR presentation and must not reproduce another app's branding/UI.

======================================================================
PART H — PRODUCT PHASING
======================================================================

PHASE 1 — THIS BUILD
Premium camera + PRO + Film Creator + GPS Map + Journey.

PHASE 2 — AFTER REAL DEVICE VALIDATION
Film Recipe Marketplace:
- users sell/buy recipes
- platform commission
- platform/IAP/payment architecture
- creator payout and tax/identity requirements

PHASE 3 — AFTER MARKETPLACE DEFINITION
Promotional website / landing page / App Store marketing assets.

DO NOT start Phase 2 or Phase 3 just because Phase 1 builds successfully.
Phase 1 must first be installed and physically evaluated.

======================================================================
END OF SINGLE SOURCE OF TRUTH
======================================================================
