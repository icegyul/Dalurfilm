# DALUR film Build Pack v1.1

Files:
- DALUR_FILM_GITHUB_SOURCE_PACK_v1.0.md
- DALUR_FILM_MASTER_SPEC_PATCH_v1.1.md
- DALUR_FILM_OPENCODE_MUSESPARK_1.3_START_PROMPT_v1.1.txt
- scripts_fetch_github_sources.sh
- scripts_fetch_github_sources.ps1

Use alongside the previously created DALUR_FILM_MASTER_DEVELOPMENT_SPEC_v1.0.md.
