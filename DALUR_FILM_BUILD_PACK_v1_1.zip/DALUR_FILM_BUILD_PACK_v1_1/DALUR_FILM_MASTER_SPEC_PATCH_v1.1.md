
# DALUR film — MASTER SPEC PATCH v1.1
Date: 2026-09-13

## PATCH 1 — GitHub source integration is now mandatory

OpenCode MUST read:
- DALUR_FILM_MASTER_DEVELOPMENT_SPEC_v1.0.md
- DALUR_FILM_GITHUB_SOURCE_PACK_v1.0.md

before implementing.

The GitHub source pack is part of the technical specification.

## PATCH 2 — Build architecture

Use a native-first architecture.

Android:
- Kotlin
- Jetpack Compose
- CameraX where sufficient
- Camera2 for low-level PRO controls
- GPUImage Plus for GPU filter/effect pipeline
- MediaCodec/MediaMuxer or the validated recorder pipeline for encoding
- WorkManager/foreground service for long renders where appropriate
- MapLibre Native for the map

iOS:
- Swift / SwiftUI
- AVFoundation
- NextLevel as a camera foundation where it reduces risk
- Metal/Core Image for the DALUR film pipeline
- AVAssetWriter / supported system encoders
- MapLibre Native or an equivalent native map layer

Shared:
- versioned Film Recipe JSON
- media metadata model
- GPS point model
- Journey model
- capability model
- deterministic export presets

## PATCH 3 — Priority order

P0:
1. Camera preview
2. Photo capture
3. Video capture
4. Film preview
5. Film save/load
6. GPS capture
7. Gallery/map
8. Journey animation preview
9. APK/AAB

P1:
10. PRO HUD
11. manual controls
12. histogram/zebra/focus tools
13. HEVC
14. real Log capability detection
15. LUT monitor toggle
16. playback LOG/LUT
17. external USB-C SSD recording
18. Journey MP4 export

P2:
19. iOS release candidate
20. accessibility and localization polish
21. store compliance package

No marketplace, no community, no promotional website.

## PATCH 4 — Journey implementation

Do not import Google Timeline.
Do not require Google account access.

DALUR creates its own photo journey from media captured by DALUR.

At capture:
- photo/video URI
- timestamp
- GPS
- altitude if available
- heading if available
- film recipe ID/version
- lens
- exposure
- video codec/profile

Journey renderer:
A. establish map
B. draw route
C. animate route line
D. move camera along route
E. pause at media point
F. animate photo reveal from that point
G. hold 0.8–2.5 seconds depending on photo count
H. continue
I. final route overview
J. export

Photo reveal should be a DALUR signature animation:
- pin pulse
- route dot grows
- photo card rises/fades/scales into place
- subtle film grain overlay
- optional film frame
- no excessive UI chrome

Presets:
- MEMORY
- CINEMA
- POSTCARD
- JOURNAL

Export:
- 9:16
- 1:1
- 16:9
- 1080p preferred
- HEVC if device/export pipeline supports it
- H.264 fallback

## PATCH 5 — PRO color architecture

Two monitoring states:
LOG VIEW
LUT VIEW

Recording master:
LOG/flat when actual device profile supports it.

Never bake the creative monitoring LUT into the PRO master.

Metadata:
- capture profile
- LUT recipe ID
- recipe version
- LUT hash
- intensity
- camera settings
- timestamp
- GPS

Playback:
- LOG
- LUT
- same master file

## PATCH 6 — USB-C

Implement direct external SSD recording where the OS/device allows it.

The capability layer must distinguish:
- internal storage
- removable storage
- external USB mass storage
- external monitor/recorder output

Do not conflate external SSD recording with HDMI/USB video output.

## PATCH 7 — Legal/licensing gate

Before release:
- generate THIRD_PARTY_NOTICES/
- include exact commit refs
- include license texts where required
- scan bundled assets
- scan dependencies
- fail release if GPL/AGPL content has been accidentally included

DALUR-original LUTs only.
No trademarked film stock names in bundled DALUR presets.

## PATCH 8 — release evidence

Before completion, generate:
release/
  DALUR-film-android-debug.apk
  DALUR-film-android-release.aab
  CHECKSUMS.txt
  DEVICE_CAPABILITY_REPORT.json
  TEST_REPORT.md
  THIRD_PARTY_NOTICES/
  STORE_READINESS.md

If signing credentials are unavailable, create unsigned or locally signed artifacts where technically possible and clearly mark store-signing as pending. Never claim a store upload occurred unless it actually did.
